Shantiniketan LPS Anganwadi — Offline PWA

Features: student registration/edit/search, CSV import, daily attendance, monthly reports, CSV export, print/Save as PDF, holidays, attendance settings, JSON backup/restore, installable PWA shell.

Important: records are saved only in this browser on this device; no cloud sync or secure multi-user login is included. Clearing browser/site data may erase records. Use Settings → Export backup regularly. Backup files contain student personal information; keep them private.

Install on Android:
1. Unzip this folder on your laptop.
2. Create a GitHub repository and upload index.html, manifest.json, sw.js and icon.svg to its root.
3. In GitHub repository Settings → Pages, publish from the main branch and /(root).
4. Open the published HTTPS URL in Chrome on Android and wait for it to load.
5. Open Chrome menu (⋮) → Install app or Add to Home screen.

PWA installation requires HTTPS (or localhost); opening index.html directly from a file manager is not enough.

Laptop test: run `python -m http.server 8000` inside this folder, then open http://localhost:8000.

This version treats the device user as an administrator. It is intended for one trusted device, not as a secure shared database.
